"""Project-owned function sources."""
